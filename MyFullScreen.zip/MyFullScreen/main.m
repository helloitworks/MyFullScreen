//
//  main.m
//  MyFullScreen
//
//  Created by shenyixin on 13-7-19.
//  Copyright (c) 2013年 http://www.helloitworks.com/. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
